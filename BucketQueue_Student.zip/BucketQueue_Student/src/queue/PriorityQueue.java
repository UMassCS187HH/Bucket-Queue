package queue;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import driver.PatientOrgan;

public class PriorityQueue {
	
	
	List<Bucket<PatientOrgan>> BucketQueue;
	int size;
	
	public PriorityQueue() {
		// TODO 1

	}
	
	public PatientOrgan get(int i){
		// TODO 2
		retun null;
	}
	
	public boolean isEmpty() {
        // TODO 3
	}
	public int size() {
        // TODO 4
        return 0;
	}
	public void enqueue(Bucket<PatientOrgan> b) {
        // TODO 5
	}
	//dequeue by priority
	public PatientOrgan dequeue() {
        // TODO 5
		
		return null;
	}
	public void sort(){
		// TODO 6
	}
	
	public String firstInLine() {
		// TODO 7
		return null;
	}
	
	
	//Return the order of priorities
	public int[] pigeonSort() {
		// TODO 8
	}
	
}
