package queue;


public class Bucket<T>{
	
}

